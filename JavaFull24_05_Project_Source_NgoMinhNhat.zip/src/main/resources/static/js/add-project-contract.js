$(document).ready(function () {
  // Thêm phương thức kiểm tra ngày lớn hơn hoặc bằng
  $.validator.addMethod(
    "dateGreaterOrEqual",
    function (value, element, params) {
      if (!value || !$(params).val()) return true; // Không kiểm tra nếu một trong hai trường trống
      return new Date(value) >= new Date($(params).val());
    },
    "" // Tin nhắn lỗi sẽ được thêm trong phần messages
  );

  // Thêm phương thức thứ hai để kiểm tra ngày khác
  $.validator.addMethod(
    "dateGreaterOrEqualExtra",
    function (value, element, params) {
      if (!value || !$(params).val()) return true; // Không kiểm tra nếu một trong hai trường trống
      return new Date(value) >= new Date($(params).val());
    },
    "" // Tin nhắn lỗi sẽ được thêm trong phần messages
  );

  $.validator.addMethod(
    "contractNumberFormat",
    function (value, element) {
      // Regex cho phép chữ cái (A-Z, a-z), số (0-9) và dấu '-'
      return this.optional(element) || /^[A-Za-z0-9\-]+$/.test(value);
    },
    "Please enter a valid contract number (letters, numbers, and '-' only)."
  );
  $.validator.addMethod(
    "noSpaces",
    function (value, element) {
      return this.optional(element) || !/\s/.test(value); // Kiểm tra nếu có dấu cách
    },
    "Contract Name must be entered." // Tin nhắn lỗi
  );

  $("form").validate({
    rules: {
      contractNumber: {
        required: true,
        contractNumberFormat: true, // Áp dụng custom validation method
        maxlength: 20, // Giới hạn tối đa 20 ký tự
      },
      airlineCode: {
        required: true,
      },
      importantLevel: {
        required: true,
      },
      region: {
        required: true,
      },
      numberOfFareSheets: {
        required: true,
        number: true,
        maxlength: 3,
        min: 1,
      },
      rtgsActual: {
        required: true,
        number: true,
        maxlength: 5,
        min: 1,
      },
      numberOfRules: {
        required: true,
        number: true,
        maxlength: 3,
        min: 1,
      },
      contractName: {
        required: true,
        noSpaces: true,
      },
      market: {
        required: true,
      },
      priority: {
        required: true,
      },
      fareType: {
        required: true,
      },
      numberOfFares: {
        required: true,
        number: true,
        maxlength: 5,
        min: 1,
      },
      rtgsRecords: {
        required: true,
        number: true,
        maxlength: 5,
        min: 1,
      },
      totalRecords: {
        required: true,
        number: true,
        maxlength: 8,
      },
      effectiveDate: {
        required: true,
        date: true,
      },
      dateClarification: {
        required: true,
        date: true,
        dateGreaterOrEqual: "#dateReceived", // Kiểm tra với Date Received
      },
      dateReceived: {
        required: true,
        date: true,
      },
      discontinueDate: {
        required: true,
        date: true,
        dateGreaterOrEqual: "#effectiveDate", // Kiểm tra với Effective Date
        dateGreaterOrEqualExtra: "#dateClarification", // Kiểm tra với Date Clarification
      },
    },
    messages: {
      contractNumber: {
        required: "Contract Number must be entered.",
        pattern: "Contract Number must be in the format of alpha numeric.",
        maxlength: "Contract Number cannot exceed 20 characters",
      },
      airlineCode: {
        required: "Airline Code must be entered.",
      },
      importantLevel: {
        required: "Important Level must be entered.",
      },
      region: {
        required: "Region must be entered.",
      },
      numberOfFareSheets: {
        required: "Number of Fare Sheets must be entered.",
        number: "Number of Fare Sheets must be entered.",
        maxlength: "Number of Fare Sheets cannot exceed 3 digits",
        min: "Number of Fare Sheets must be a number and > 0.",
      },
      rtgsActual: {
        required: "Rtgs Actual must be entered.",
        number: "Rtgs Actual must be entered.",
        maxlength: "Rtgs Actual cannot exceed 5 digits",
        min: "Rtgs Actual must be a number and > 0.",
      },
      numberOfRules: {
        required: "Number of Rules must be entered.",
        number: "Number of Rules must be entered.",
        maxlength: "Number of Rules cannot exceed 3 digits",
        min: "Number of Rules must be a number and > 0.",
      },
      contractName: {
        required: "Contract Name must be entered.",
      },
      market: {
        required: "Market is required.",
      },
      priority: {
        required: "Priority is required.",
      },
      fareType: {
        required: "Fare Type is required.",
      },
      numberOfFares: {
        required: "Number of Fares must be entered.",
        number: "Please enter a valid number",
        maxlength: "Number of Fares cannot exceed 5 digits",
        min: "Number of Fares must be a number and > 0.",
      },
      rtgsRecords: {
        required: "Rtgs Records must be entered.",
        number: "Please enter a valid number",
        maxlength: "Rtgs Records cannot exceed 5 digits",
        min: "Rtgs Records must be a number and > 0.",
      },
      totalRecords: {
        required: "Total Records must be entered.",
        number: "Please enter a valid number",
        maxlength: "Total Records cannot exceed 8 digits",
      },
      effectiveDate: {
        required: "Effective Date must be entered.",
        date: "Effective Date must be a Date type.",
      },
      dateClarification: {
        required: "Date Clarification Cleared must be entered.",
        date: "Date Clarification Cleared must be a Date type.",
        dateGreaterOrEqual:
          "Date Clarification must be later than or equals to Date Received.",
      },
      dateReceived: {
        required: "Date Received must be entered.",
        date: "Date Received must be a Date type.",
      },
      discontinueDate: {
        required: "Discontinue Date must be entered.",
        date: "Discontinue Date must be a Date type.",
        dateGreaterOrEqual:
          "Discontinue Date must be later than or equals to Effective Date.",
        dateGreaterOrEqualExtra:
          "Discontinue Date must be later than or equals to Date Clarification.",
      },
    },
    highlight: function (element) {
      $(element).addClass("is-invalid"); // Chỉ cần thêm label này
    },
    unhighlight: function (element) {
      $(element).removeClass("is-invalid");
      $("#" + element.id + "-error").hide(); // Ẩn thông báo lỗi nếu hợp lệ
    },
    submitHandler: function (form) {
      alert("Form submitted successfully!");
      form.reset();
    },
  });

  $("#effectiveDate").on("change", function () {
    // Kiểm tra lại trường discontinueDate
    $("#effectiveDate").valid(); // Gọi valid để kiểm tra lỗi
  });

  $("#dateClarification").on("change", function () {
    // Kiểm tra lại trường discontinueDate
    $("#dateClarification").valid(); // Gọi valid để kiểm tra lỗi
  });
  $("#dateReceived").on("change", function () {
    // Kiểm tra lại trường discontinueDate
    $("#dateReceived").valid(); // Gọi valid để kiểm tra lỗi
  });
});
