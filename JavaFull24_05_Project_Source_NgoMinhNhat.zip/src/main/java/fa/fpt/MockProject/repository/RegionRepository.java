package fa.fpt.MockProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fa.fpt.MockProject.entities.Region;

public interface RegionRepository extends JpaRepository<Region, String>{
	List<Region> findAllByOrderByNameAsc();
}
