package fa.fpt.MockProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fa.fpt.MockProject.entities.FareType;

public interface FareTypeRepository extends JpaRepository<FareType, String> {
	List<FareType> findAllByOrderByNameAsc();
}
