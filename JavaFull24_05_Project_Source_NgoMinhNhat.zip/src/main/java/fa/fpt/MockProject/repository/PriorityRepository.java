package fa.fpt.MockProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fa.fpt.MockProject.entities.Priority;


public interface PriorityRepository extends JpaRepository<Priority, Long> {
	List<Priority> findAllByOrderByNameAsc();
}
