package fa.fpt.MockProject.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import fa.fpt.MockProject.entities.Contract;

public interface ContractRepository extends JpaRepository<Contract, String>, JpaSpecificationExecutor<Contract>  {
	 // Lấy danh sách Contract Numbers dựa vào Market và Airline  
    @Query("SELECT DISTINCT c.contractNumber FROM Contract c WHERE c.country.countryCode = :market AND c.airline.code = :airline")  
    List<String> findContractNumbersByMarketAndAirline(@Param("market") String market, @Param("airline") String airline);  

    // Lấy danh sách Fare Types dựa vào Market và Airline  
    @Query("SELECT DISTINCT c.fareType.code FROM Contract c WHERE c.country.countryCode = :market AND c.airline.code = :airline")  
    List<String> findFareTypesByMarketAndAirline(@Param("market") String market, @Param("airline") String airline);  

//    @Query("SELECT c FROM Contract c " +  
//    	       "WHERE c.country.countryCode = :market " +  
//    	       "AND c.airline.code = :airline " +  
//    	       "AND (:contractNumber IS NULL OR c.contractNumber = :contractNumber) " +
//    	       "AND (:fareType IS NULL OR c.fareType.code = :fareType) " +
//    	       "AND (:discontinueDate IS NULL OR c.discontinueDate = :discontinueDate) " +  
//    	       "AND (:effectiveDate IS NULL OR c.effectiveDate = :effectiveDate) " +  
//    	       "AND (:dateReceived IS NULL OR c.dateReceived = :dateReceived)")  
//    Page<Contract> filterContractsByCriteria(  
//    	        @Param("market") Long market,  
//    	        @Param("airline") Long airline,  
//    	        @Param("contractNumber") String contractNumber,  
//    	        @Param("fareType") String fareType,  
//    	        @Param("discontinueDate") LocalDate discontinueDate,  
//    	        @Param("effectiveDate") LocalDate effectiveDate,  
//    	        @Param("dateReceived") LocalDate dateReceived,
//    	        Pageable pageable);
    
    @Query("SELECT c FROM Contract c " +  
 	       "WHERE c.country.countryCode = :market " +  
 	       "AND c.airline.code = :airline " +  
 	       "AND (:contractNumber IS NULL OR c.contractNumber = :contractNumber) " +
 	       "AND (:fareType IS NULL OR c.fareType.code = :fareType) " )  
 Page<Contract> filterContractsByCriteria(  
 	        @Param("market") Long market,  
 	        @Param("airline") Long airline,  
 	        @Param("contractNumber") String contractNumber,  
 	        @Param("fareType") String fareType,
 	        Pageable pageable);
    
		/*
		 * @Query("SELECT c FROM Contract c " + "WHERE c.country.countryCode = :market "
		 * + "AND c.airline.code = :airline ") Page<Contract> filterContractsByCriteria(
		 * 
		 * @Param("market") Long market,
		 * 
		 * @Param("airline") Long airline,Pageable pageable);
		 */
    }