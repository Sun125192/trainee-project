package fa.fpt.MockProject.entities;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


//Model for CONTRACT
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "CONTRACT")
public class Contract {

	@Id
	@NotBlank(message = "Contract Number must be entered.")
	@Pattern(regexp = "^[A-Za-z0-9\\-]+$", message = "Contract Number must be in the format of alpha numeric.")
	@Column(name = "CONTRACT_NUMBER", columnDefinition = "VARCHAR(20)", nullable = false)
	private String contractNumber;

	@NotBlank(message = "Contract Name must be entered.")
	@Column(name = "NAME",columnDefinition = "VARCHAR(100)", nullable = false)
	private String name;

	@ManyToOne
	@JoinColumn(name = "AIRLINE_ID", referencedColumnName = "code", nullable = false)
	private Airline airline;

	@ManyToOne
	@JoinColumn(name = "MARKET",referencedColumnName = "COUNTRY_CODE", nullable = false)
	private Country country;

	@Column(name = "IMPORTANT_LEVEL", nullable = false)
	private String importantLevel;

	@ManyToOne
	@JoinColumn(name = "PRIORITY_CODE", referencedColumnName = "CODE", nullable = false)
	private Priority priority;

	@ManyToOne
	@JoinColumn(name = "REGION_ID", referencedColumnName = "CODE", nullable = false)
	private Region region;

	@ManyToOne
	@JoinColumn(name = "FARE_TYPE", referencedColumnName = "CODE", nullable = false)
	private FareType fareType;

	@NotNull(message = "Date Received must be entered.")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "DATE_RECEIVED", nullable = false)
	private LocalDate dateReceived;

	@NotNull(message = "Discontinue Date must be entered.")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "DISCONTINUE_DATE", nullable = false)
	private LocalDate discontinueDate;

	@NotNull(message = "Effective Date must be entered.")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "EFFECTIVE_DATE", nullable = false)
	private LocalDate effectiveDate;

	@NotNull(message="Date Clarification Cleared must be entered.")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "DATE_CLARIFICATION_CLEARED", nullable = false)
	private LocalDate dateClarificationCleared;
	
	@NotNull(message="Number of Fare Sheets must be entered.")
	@Min(value = 1, message = "Number of Fare Sheets must be a number and > 0.")
	@Max(value = 999, message = "")
	@Column(name = "FARE_SHEETS", nullable = false)
	private Integer numberOfFareSheets;

	@NotNull(message="Number of Fares must be entered.")
	@Min(value = 1, message = "Number of Fare must be a number and > 0.")
	@Max(value = 99999, message = "")
	@Column(name = "NUMBER_OF_FARES", nullable = false)
	private Integer numberOfFares;

	@NotNull(message="Rtgs Actual must be entered.")
	@Min(value = 1, message = "Rtgs Actual must be a number and > 0.")
	@Max(value = 99999, message = "")
	@Column(name = "RTGS_ACTUAL", nullable = false)
	private Integer rtgsActual;

	@NotNull(message="Rtgs Records must be entered.")
	@Min(value = 1, message = "Rtgs Records must be a number and > 0.")
	@Max(value = 99999, message = "")
	@Column(name = "RTGS_RECORDS", nullable = false)
	private Integer rtgsRecords;

	@NotNull(message="Number of Rules must be entered.")
	@Min(value = 1, message = "Number of Rules must be a number and > 0.")
	@Max(value = 999, message = "")
	@Column(name = "RULES", nullable = false)
	private Integer numberOfRules;

	@Column(name = "TOTAL_RECORDS", nullable = false)
	private Integer totalRecords;

	@Column(name = "QUEUING_START_DATE", nullable = false)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private LocalDate queuingStartDate;

	@Column(name = "QUEUING_END_DATE")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private LocalDate queuingEndDate;

	
	// Getters and Setters
	
	
	@Override
	public String toString() {
		return "Contract [contractNumber=" + contractNumber + ", name=" + name + ", airline=" + airline + ", country="
				+ country + ", importantLevel=" + importantLevel + ", priority=" + priority + ", region=" + region
				+ ", fareType=" + fareType + ", dateReceived=" + dateReceived + ", discontinueDate=" + discontinueDate
				+ ", effectiveDate=" + effectiveDate + ", dateClarificationCleared=" + dateClarificationCleared
				+ ", numberOfFareSheets=" + numberOfFareSheets + ", numberOfFares=" + numberOfFares + ", rtgsActual="
				+ rtgsActual + ", rtgsRecords=" + rtgsRecords + ", numberOfRules=" + numberOfRules + ", totalRecords="
				+ totalRecords + ", queuingStartDate=" + queuingStartDate + ", queuingEndDate=" + queuingEndDate + "]";
	}


	/**
	 * @param contractNumber
	 * @param name
	 * @param airline
	 * @param country
	 * @param importantLevel
	 * @param priority
	 * @param region
	 * @param fareType
	 * @param dateReceived
	 * @param discontinueDate
	 * @param effectiveDate
	 * @param dateClarificationCleared
	 * @param numberOfFareSheets
	 * @param numberOfFares
	 * @param rtgsActual
	 * @param rtgsRecords
	 * @param numberOfRules
	 * @param totalRecords
	 * @param queuingStartDate
	 * @param queuingEndDate
	 */
	public Contract(
			@NotBlank(message = "Contract Number must be entered.") @Pattern(regexp = "^[A-Za-z0-9\\-]+$", message = "Contract Number must be in the format of alpha numeric.") String contractNumber,
			@NotBlank(message = "Contract Name must be entered.") String name, Airline airline, Country country,
			String importantLevel, Priority priority, Region region, FareType fareType,
			@NotNull(message = "Date Received must be entered.") LocalDate dateReceived,
			@NotNull(message = "Discontinue Date must be entered.") LocalDate discontinueDate,
			@NotNull(message = "Effective Date must be entered.") LocalDate effectiveDate,
			@NotNull(message = "Date Clarification Cleared must be entered.") LocalDate dateClarificationCleared,
			@NotNull(message = "Number of Fare Sheets must be entered.") @Min(value = 1, message = "Number of Fare Sheets must be a number and > 0.") @Max(value = 999, message = "") Integer numberOfFareSheets,
			@NotNull(message = "Number of Fares must be entered.") @Min(value = 1, message = "Number of Fare must be a number and > 0.") @Max(value = 99999, message = "") Integer numberOfFares,
			@NotNull(message = "Rtgs Actual must be entered.") @Min(value = 1, message = "Rtgs Actual must be a number and > 0.") @Max(value = 99999, message = "") Integer rtgsActual,
			@NotNull(message = "Rtgs Records must be entered.") @Min(value = 1, message = "Rtgs Records must be a number and > 0.") @Max(value = 99999, message = "") Integer rtgsRecords,
			@NotNull(message = "Number of Rules must be entered.") @Min(value = 1, message = "Number of Rules must be a number and > 0.") @Max(value = 999, message = "") Integer numberOfRules,
			Integer totalRecords, LocalDate queuingStartDate, LocalDate queuingEndDate) {
		super();
		this.contractNumber = contractNumber;
		this.name = name;
		this.airline = airline;
		this.country = country;
		this.importantLevel = importantLevel;
		this.priority = priority;
		this.region = region;
		this.fareType = fareType;
		this.dateReceived = dateReceived;
		this.discontinueDate = discontinueDate;
		this.effectiveDate = effectiveDate;
		this.dateClarificationCleared = dateClarificationCleared;
		this.numberOfFareSheets = numberOfFareSheets;
		this.numberOfFares = numberOfFares;
		this.rtgsActual = rtgsActual;
		this.rtgsRecords = rtgsRecords;
		this.numberOfRules = numberOfRules;
		this.totalRecords = totalRecords;
		this.queuingStartDate = queuingStartDate;
		this.queuingEndDate = queuingEndDate;
	}
}
