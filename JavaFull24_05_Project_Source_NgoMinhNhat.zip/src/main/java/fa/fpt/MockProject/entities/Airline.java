package fa.fpt.MockProject.entities;


import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//Model for AIRLINE
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "AIRLINE")
public class Airline {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CODE")
	private Long code;

	@Column(name = "NAME", columnDefinition = "VARCHAR(5)")
	private String name;
	
	@OneToMany(mappedBy = "airline")
	private Set<Contract> contracts;

	// Getters and Setters
}
