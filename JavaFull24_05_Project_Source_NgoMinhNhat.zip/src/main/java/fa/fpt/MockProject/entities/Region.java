package fa.fpt.MockProject.entities;



import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//Model for REGION
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "REGION")
public class Region {

	@Id
	@Column(name = "CODE", columnDefinition = "varchar(10)")
	private String code;

	@Column(name = "NAME", columnDefinition = "varchar(50)")
	private String name;
	
	@OneToMany(mappedBy = "region")
	private Set<Contract> contracts;

	// Getters and Setters
}
