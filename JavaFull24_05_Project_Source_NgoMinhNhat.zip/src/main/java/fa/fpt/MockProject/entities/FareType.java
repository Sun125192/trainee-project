package fa.fpt.MockProject.entities;



import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//Model for FARE_TYPE
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "FARE_TYPE")
public class FareType {

	@Id
	@Column(name = "CODE",columnDefinition = "varchar(1)")
	private String code;

	@Column(name = "NAME", columnDefinition = "varchar(50)")
	private String name;
	
	@OneToMany(mappedBy = "fareType")
	private Set<Contract> contracts;

	

	// Getters and Setters
}
