package fa.fpt.MockProject.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import fa.fpt.MockProject.dto.ContractDTOList;
import fa.fpt.MockProject.dto.FilterConTractDTO;
import fa.fpt.MockProject.entities.Airline;
import fa.fpt.MockProject.entities.Country;
import fa.fpt.MockProject.service.AirlineService;
import fa.fpt.MockProject.service.ContractService;
import fa.fpt.MockProject.service.CountryService;
import fa.fpt.MockProject.utils.Constant;
import fa.fpt.MockProject.utils.Pagination;

@Controller
public class FilterController {

	@Autowired
	private ContractService contractService;

	@Autowired
	private CountryService countryService;

	@Autowired
	private AirlineService airlineService;

	/**
	 * Phương thức xử lý danh sách và thao tác lọc hợp đồng.
	 *
	 * @param model Mô hình để thêm các thuộc tính vào view.
	 * @param action Thao tác (lọc hoặc xem) cần thực hiện.
	 * @param market Bộ lọc thị trường.
	 * @param airline Bộ lọc hãng hàng không.
	 * @param contractNumber Bộ lọc số hợp đồng.
	 * @param fareType Bộ lọc loại vé.
	 * @param discontinueDate Bộ lọc ngày ngừng hiệu lực.
	 * @param effectiveDate Bộ lọc ngày bắt đầu hiệu lực.
	 * @param dateReceived Bộ lọc ngày nhận.
	 * @param page Số trang cho phân trang.
	 * @return Tên view.
	 * 
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	@GetMapping("/list")
	public String listOrFilter(Model model, @RequestParam(required = false, defaultValue = "") String action,
			@RequestParam(required = false) String market, @RequestParam(required = false) String airline,
			@RequestParam(required = false) String contractNumber, @RequestParam(required = false) String fareType,
			@RequestParam(required = false) String discontinueDate, @RequestParam(required = false) String effectiveDate,
			@RequestParam(required = false) String dateReceived, @RequestParam(required = false, defaultValue = "1") int page) {

		// Biến cho phân trang và danh sách hợp đồng
		int recordsPerPage = Constant.SIZE_PAGE;
		long totalRecords = 0;

		// Kiểm tra và phân tích các tham số
		Long marketId = parseLongParam(market, model);
		Long airlineId = parseLongParam(airline, model);

		if (marketId == null || airlineId == null) {
			return "errorPage"; // Nếu lỗi, trả về trang lỗi
		}

		// Lấy danh sách các quốc gia và hãng hàng không
		List<Country> countrylist = countryService.findAll();
		List<Airline> airlinelist = airlineService.findAll();

		// Thiết lập phân trang
		Pagination pagination = new Pagination();
		List<ContractDTOList> contractList;

		if (Constant.FILTER_ACTION.equals(action) && marketId != null && airlineId != null) {
			// Xử lý lọc theo các tham số
			LocalDate parsedDiscontinueDate = parseDate(discontinueDate);
			LocalDate parsedEffectiveDate = parseDate(effectiveDate);
			LocalDate parsedDateReceived = parseDate(dateReceived);

			// Lọc các hợp đồng theo các tham số đã cung cấp
			contractList = contractService.formDtoMapEntity(
					contractService.filterContracts(marketId, airlineId, contractNumber, fareType, parsedDiscontinueDate, parsedEffectiveDate, parsedDateReceived, page, recordsPerPage));

			totalRecords = contractService.countFilteredRecords(marketId, airlineId, contractNumber, fareType,
					parsedDiscontinueDate, parsedEffectiveDate, parsedDateReceived, page, recordsPerPage);

			pagination = Pagination.calculatePagination((int) totalRecords, page, recordsPerPage);

			model.addAttribute("market", marketId);
			model.addAttribute("airline", airlineId);
			model.addAttribute(Constant.FILTER_ACTION, action);
		} else {
			// Lấy tất cả hợp đồng nếu không có bộ lọc
			totalRecords = contractService.totalrecord();
			contractList = contractService.formDtoMapEntity(contractService.findAllByPage(page, recordsPerPage));
			pagination = Pagination.calculatePagination((int) totalRecords, page, recordsPerPage);
		}

		// Thêm các thuộc tính vào model để gửi đến view
		model.addAttribute("contractList", contractList);
		model.addAttribute("pagination", pagination);
		model.addAttribute("countryList", countrylist);
		model.addAttribute("airlinelist", airlinelist);

		return "projectContractInfo/filter-project-contract";
	}

	// Phương thức chuyển đổi chuỗi thành LocalDate
	private LocalDate parseDate(String dateStr) {
		if (dateStr != null && !dateStr.isEmpty()) {
			return LocalDate.parse(dateStr);
		}
		return null;
	}

	/**
	 * Phương thức xử lý việc lọc hợp đồng và chuyển hướng tới trang danh sách với các tham số.
	 * 
	 * @param request Đối tượng FilterConTractDTO chứa các tiêu chí lọc.
	 * @param redirectAttributes Các thuộc tính chuyển hướng cho URL.
	 * @return URL chuyển hướng tới trang danh sách.
	 *
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	@PostMapping("/filter")
	public String filterContracts(@ModelAttribute FilterConTractDTO request, RedirectAttributes redirectAttributes) {
		// Kiểm tra các trường bắt buộc
		if (request.getMarket() == null || request.getAirline() == null) {
			throw new IllegalArgumentException("Market and Airline are required fields.");
		}

		// Thêm các tiêu chí lọc vào thuộc tính chuyển hướng
		redirectAttributes.addAttribute("market", request.getMarket());
		redirectAttributes.addAttribute("airline", request.getAirline());
		redirectAttributes.addAttribute("contractNumber", request.getContractNumber());
		redirectAttributes.addAttribute("fareType", request.getFareType());
		redirectAttributes.addAttribute("discontinueDate", request.getDiscontinueDate());
		redirectAttributes.addAttribute("effectiveDate", request.getEffectiveDate());
		redirectAttributes.addAttribute("dateReceived", request.getDateReceived());
		redirectAttributes.addAttribute("action", Constant.FILTER_ACTION);

		// Chuyển hướng tới trang danh sách với các tham số lọc đã cập nhật
		return "redirect:/list";
	}

	/**
	 * Phương thức tải số hợp đồng và loại vé dựa trên thị trường và hãng hàng không đã chọn.
	 * 
	 * @param market Thị trường đã chọn.
	 * @param airline Hãng hàng không đã chọn.
	 * @return ResponseEntity chứa số hợp đồng và loại vé đã lọc.
	 *
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	@GetMapping("/market-and-airline")
	public ResponseEntity<Map<String, List<Map<String, String>>>> filterContractsByMarketAndAirline (
			@RequestParam(required = false) String market, @RequestParam(required = false) String airline) {

		if (market == null || airline == null || market.isEmpty() || airline.isEmpty()) {
			Map<String, List<Map<String, String>>> emptyResponse = new HashMap<>();
			emptyResponse.put("contractNumbers", new ArrayList<>());
			emptyResponse.put("fareTypes", new ArrayList<>());
			return ResponseEntity.ok(emptyResponse);
		}

		List<Map<String, String>> contractNumbers = contractService.getContractNumbersByMarketAndAirline(market,
				airline);
		List<Map<String, String>> fareTypes = contractService.getFareTypesByMarketAndAirline(market, airline);

		Map<String, List<Map<String, String>>> response = new HashMap<>();
		response.put("contractNumbers", contractNumbers != null ? contractNumbers : new ArrayList<>());
		response.put("fareTypes", fareTypes != null ? fareTypes : new ArrayList<>());

		return ResponseEntity.ok(response);
	}
	 
	/**
	 * Phương thức kiểm tra và chuyển đổi chuỗi thành Long.
	 * 
	 * Phương thức này nhận vào một chuỗi và kiểm tra xem nó có phải là một chuỗi hợp lệ hay không. 
	 * Nếu chuỗi không rỗng và có thể chuyển đổi sang kiểu Long, phương thức sẽ thực hiện chuyển đổi.
	 * Nếu không, một thông báo lỗi sẽ được thêm vào model và trả về giá trị null.
	 *
	 * @param param Chuỗi cần kiểm tra và chuyển đổi.
	 * @param model Mô hình (model) để thêm thông báo lỗi nếu có.
	 * @return Giá trị Long tương ứng nếu chuỗi hợp lệ, hoặc null nếu chuỗi không hợp lệ hoặc có lỗi.
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	private Long parseLongParam(String param, Model model) {
		if (param != null && !param.isEmpty() && !"null".equals(param)) {
			try {
				return Long.parseLong(param);
			} catch (NumberFormatException e) {
				model.addAttribute("error", "Invalid value for parameter: " + param);
				return null;
			}
		}
		return null;
	}
}
