package fa.fpt.MockProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fa.fpt.MockProject.dto.ContractDTOForm;
import fa.fpt.MockProject.entities.Contract;
import fa.fpt.MockProject.service.AirlineService;
import fa.fpt.MockProject.service.ContractService;
import fa.fpt.MockProject.service.CountryService;
import fa.fpt.MockProject.service.FareTypeService;
import fa.fpt.MockProject.service.PriorityService;
import fa.fpt.MockProject.service.RegionService;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/contract")
public class UpdateController {

	@Autowired
	private AirlineService airlineService;
	@Autowired
	private CountryService countryService;
	@Autowired
	private PriorityService priorityService;
	@Autowired
	private FareTypeService fareTypeService;
	@Autowired
	private RegionService regionService;
	@Autowired
	private ContractService contractService;

	/**
	 * Phương thức hiển thị màn hình Project/Contract Information Maintenance – Update
	 *
	 * @param contractNumber
	 * @param model
	 * @return
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	@GetMapping("/update")
	public String showUpdate(@RequestParam(required = false) String contractNumber, Model model) {
		loadFormData(model);

		System.out.println("====================== SHOW UPDATE ======================");
		System.out.println("ContractNumber: " + contractNumber);
		
		
		ContractDTOForm contractDTOForm = contractService.mapEntityToDtoForm(contractService.findById(contractNumber));
		model.addAttribute("contractForm", contractDTOForm);

		return "projectContractInfo/update-project-contract";
	}

	/**
	 * Phương thức thực hiện project/Contract Information Maintenance – Update
	 *
	 * @param contractDTOForm
	 * @param result
	 * @param model
	 * @return
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	@PostMapping("/update")
	public String doUpdate(@Valid @ModelAttribute("contractForm") ContractDTOForm contractDTOForm, BindingResult result,
			Model model) {

		System.out.println("====================== DO UPDATE ======================");
		System.out.println("contractDTOForm: " + contractDTOForm);

		if (result.hasErrors()) {
			loadFormData(model);
			return "projectContractInfo/update-project-contract";
		}

		if (contractService.isContractModified(contractDTOForm)) {
			model.addAttribute("errorMessage",
					"The selected record has been changed by another user! Please refresh to get the latest data for your update.");
			ContractDTOForm latestContractForm = contractService
					.mapEntityToDtoForm(contractService.findById(contractDTOForm.getContractNumber()));
			model.addAttribute("contractForm", latestContractForm);
			loadFormData(model);
			return "projectContractInfo/update-project-contract";
		}

		Contract contract = contractService.mapDtoFormToEntity(contractDTOForm);
		System.out.println("contract: " + contract);

		if (contractService.create(contract) != null) {
			model.addAttribute("successMessage", "Contract updated successfully!");
			return "redirect:/list";
		} else {
			model.addAttribute("errorMessage", "Database connection error.");
			loadFormData(model);
			return "projectContractInfo/update-project-contract";
		}
	}

	/**
	 * Phương thức tải dữ liệu để hiển thị lên form project/Contract Information Maintenance – Update
	 *
	 * @param model
	 * @author Ngo Minh Nhat
	 * @birthDay 2001-05-12
	 * @class DN24_FRF_FJW_05
	 */
	private void loadFormData(Model model) {
		model.addAttribute("listCountries", countryService.findAll());
		model.addAttribute("listAirlines", airlineService.findAll());
		model.addAttribute("listPriorities", priorityService.findAll());
		model.addAttribute("listFareTypes", fareTypeService.findAll());
		model.addAttribute("listRegions", regionService.findAll());
	}
}
