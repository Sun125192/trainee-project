package fa.fpt.MockProject.specification;

import java.time.LocalDate;

import org.springframework.data.jpa.domain.Specification;

import fa.fpt.MockProject.entities.Contract;
import jakarta.persistence.criteria.Predicate;

public class ContractSpecifications {
	public static Specification<Contract> byCriteria(Long market, Long airline, String contractNumber, String fareType,
	        LocalDate discontinueDate, LocalDate effectiveDate, LocalDate dateReceived) {
	    return (root, query, criteriaBuilder) -> {
	        Predicate predicate = criteriaBuilder.conjunction();

	        // Required: Market (Country)
	        if (market == null) {
	            throw new IllegalArgumentException("Market (country) is required.");
	        }
	        predicate = criteriaBuilder.and(predicate,
	                criteriaBuilder.equal(root.get("country").get("countryCode"), market));

	        // Required: Airline
	        if (airline == null) {
	            throw new IllegalArgumentException("Airline is required.");
	        }
	        predicate = criteriaBuilder.and(predicate,
	                criteriaBuilder.equal(root.get("airline").get("code"), airline));

	        // Optional: Contract Number (partial match with like)
	        if (contractNumber != null && !contractNumber.isEmpty()) {
	            predicate = criteriaBuilder.and(predicate,
	                    criteriaBuilder.like(root.get("contractNumber"), "%" + contractNumber + "%"));
	        }

	        // Optional: Fare Type
	        if (fareType != null && !fareType.isEmpty()) {
	            predicate = criteriaBuilder.and(predicate,
	                    criteriaBuilder.equal(root.get("fareType").get("code"), fareType));
	        }

	        // Optional: Discontinue Date
	        if (discontinueDate != null) {
	            predicate = criteriaBuilder.and(predicate,
	                    criteriaBuilder.equal(root.get("discontinueDate"), discontinueDate));
	        }

	        // Optional: Effective Date
	        if (effectiveDate != null) {
	            predicate = criteriaBuilder.and(predicate,
	                    criteriaBuilder.equal(root.get("effectiveDate"), effectiveDate));
	        }

	        // Optional: Date Received
	        if (dateReceived != null) {
	            predicate = criteriaBuilder.and(predicate,
	                    criteriaBuilder.equal(root.get("dateReceived"), dateReceived));
	        }

	        return predicate;
	    };
	}

}