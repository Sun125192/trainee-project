package fa.fpt.MockProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fa.fpt.MockProject.entities.Country;
import fa.fpt.MockProject.repository.CountryRepository;
@Service
@Transactional
public class CountryService {
	@Autowired
	private CountryRepository countryRepository;
	
	public List<Country> findAll() {
		return countryRepository.findAllByOrderByNameAsc();
	}
}
