package fa.fpt.MockProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fa.fpt.MockProject.entities.FareType;
import fa.fpt.MockProject.repository.FareTypeRepository;
@Service
@Transactional
public class FareTypeService {
	@Autowired
	private FareTypeRepository fareTypeRepository;
	
	public List<FareType> findAll() {
		return fareTypeRepository.findAllByOrderByNameAsc();
	}
}
