package fa.fpt.MockProject.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fa.fpt.MockProject.dto.ContractDTOForm;
import fa.fpt.MockProject.dto.ContractDTOList;
import fa.fpt.MockProject.entities.Contract;
import fa.fpt.MockProject.entities.FareType;
import fa.fpt.MockProject.repository.AirlineRepository;
import fa.fpt.MockProject.repository.ContractRepository;
import fa.fpt.MockProject.repository.CountryRepository;
import fa.fpt.MockProject.repository.FareTypeRepository;
import fa.fpt.MockProject.repository.PriorityRepository;
import fa.fpt.MockProject.repository.RegionRepository;
import fa.fpt.MockProject.specification.ContractSpecifications;

@Service
@Transactional
public class ContractService {
	@Autowired
	private ContractRepository contractRepository;

	@Autowired
	private AirlineRepository airlineRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private FareTypeRepository fareTypeRepository;

	@Autowired
	private PriorityRepository priorityRepository;
	
	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private FareTypeService fareTypeService;

	public Contract create(Contract contract) {
		return contractRepository.save(contract);
	}

	public List<Contract> findAll() {
		return contractRepository.findAll();
	}

	public Contract findById(String id) {
		return contractRepository.findById(id).orElse(null);
	}

	public List<Contract> findAllByPage(int start, int pageSize) {
		Pageable pageable = PageRequest.of(start - 1, pageSize);
		Page<Contract> listPage = contractRepository.findAll(pageable);
		return listPage.getContent();
	}

	public long totalrecord() {
		return contractRepository.count();
	}

	public List<Map<String, String>> getContractNumbersByMarketAndAirline(String market, String airline) {
		List<String> contractNumbers = contractRepository.findContractNumbersByMarketAndAirline(market, airline);
		return contractNumbers.stream().map(contractNumber -> Map.of("value", contractNumber, "text", contractNumber))
				.collect(Collectors.toList());
	}

	public List<Map<String, String>> getFareTypesByMarketAndAirline(String market, String airline) {
		List<String> fareTypes = contractRepository.findFareTypesByMarketAndAirline(market, airline);
		List<FareType> fareTypeList = fareTypeService.findAll();
		List<FareType> fareTypeShow = new ArrayList<>();

		for (String string : fareTypes) {
			for (FareType fareType : fareTypeList) {
				if (string.equals(fareType.getCode())) {
					fareTypeShow.add(fareType);
				}
			}
		}

		return fareTypeShow.stream().map(fareType -> Map.of("value", fareType.getCode(), "text",
				fareType.getCode() + " - " + fareType.getName())).collect(Collectors.toList());
	}

	public long countFilteredRecords(Long market, Long airline, String contractNumber, String fareType,
			LocalDate discontinueDate, LocalDate effectiveDate, LocalDate dateReceived, int start, int pageSize) {
		Specification<Contract> spec = ContractSpecifications.byCriteria(market, airline, contractNumber, fareType,
				discontinueDate, effectiveDate, dateReceived);
		Pageable pageable = PageRequest.of(start - 1, pageSize);
		Page<Contract> page = contractRepository.findAll(spec, pageable);
		return page.getTotalElements();
	}

	public List<Contract> filterContracts(Long market, Long airline, String contractNumber, String fareType,
			LocalDate discontinueDate, LocalDate effectiveDate, LocalDate dateReceived, int start, int pageSize) {
		Specification<Contract> spec = ContractSpecifications.byCriteria(market, airline, contractNumber, fareType,
				discontinueDate, effectiveDate, dateReceived);
		Pageable pageable = PageRequest.of(start - 1, pageSize);
		Page<Contract> page = contractRepository.findAll(spec, pageable);
		return page.getContent();
	}
	
	public boolean isContractModified(ContractDTOForm contractDTOForm) {
	    Contract contractInDb = findById(contractDTOForm.getContractNumber());
	    if (contractInDb != null) {
	        return !contractInDb.getEffectiveDate().equals(contractDTOForm.getEffectiveDate());
	    }
	    return false;
	}

	public List<ContractDTOList> formDtoMapEntity(List<Contract> listContract) {
		List<ContractDTOList> listContractDTOList = new ArrayList<>();
		for (Contract contract : listContract) {
			ContractDTOList contractDTOList = new ContractDTOList();
			contractDTOList.setContractNumber(contract.getContractNumber());
			contractDTOList.setAirlineCode(contract.getAirline().getName());
			contractDTOList.setMarket(contract.getCountry().getName());
			contractDTOList.setRegion(contract.getRegion().getName());
			contractDTOList.setFareType(contract.getFareType().getName());
			contractDTOList.setDateReceived(contract.getDateReceived());
			contractDTOList.setEffectiveDate(contract.getEffectiveDate());
			contractDTOList.setDiscontinueDate(contract.getDiscontinueDate());
			contractDTOList.setPriority(contract.getPriority().getName());

			listContractDTOList.add(contractDTOList);
		}
		return listContractDTOList;
	}

	public ContractDTOForm mapEntityToDtoForm (Contract contract) {
		ContractDTOForm contractDTOForm = new ContractDTOForm();

		contractDTOForm.setContractNumber(contract.getContractNumber());
		contractDTOForm.setContractName(contract.getName());
		contractDTOForm.setAirlineCode(contract.getAirline().getCode());
		contractDTOForm.setCountryCode(contract.getCountry().getCountryCode());
		contractDTOForm.setImportantLevel(contract.getImportantLevel());
		contractDTOForm.setPriority(contract.getPriority().getCode());
		contractDTOForm.setRegion(contract.getRegion().getCode());
		contractDTOForm.setFareType(contract.getFareType().getCode());
		contractDTOForm.setDateReceived(contract.getDateReceived());
		contractDTOForm.setEffectiveDate(contract.getEffectiveDate());
		contractDTOForm.setDiscontinueDate(contract.getDiscontinueDate());
		contractDTOForm.setDateClarificationCleared(contract.getDateClarificationCleared());
		contractDTOForm.setNumberOfFareSheets(contract.getNumberOfFareSheets());
		contractDTOForm.setNumberOfFares(contract.getNumberOfFares());
		contractDTOForm.setRtgsActual(contract.getRtgsActual());
		contractDTOForm.setRtgsRecords(contract.getRtgsRecords());
		contractDTOForm.setNumberOfRules(contract.getNumberOfRules());
		contractDTOForm.setTotalRecords(contract.getTotalRecords());
		contractDTOForm.setQueuingStartDate(contract.getQueuingStartDate());
		contractDTOForm.setQueuingEndDate(contract.getQueuingEndDate());

		return contractDTOForm;
	}

	public Contract mapDtoFormToEntity(ContractDTOForm contractDTOForm) {
		Contract contract = new Contract();

		contract.setContractNumber(contractDTOForm.getContractNumber());
		contract.setName(contractDTOForm.getContractName());
		contract.setAirline(airlineRepository.findById(contractDTOForm.getAirlineCode()).orElse(null));
		contract.setCountry(countryRepository.findById(contractDTOForm.getCountryCode()).orElse(null));
		contract.setImportantLevel(contractDTOForm.getImportantLevel());
		contract.setPriority(priorityRepository.findById(contractDTOForm.getPriority()).orElse(null));
		contract.setRegion(regionRepository.findById(contractDTOForm.getRegion()).orElse(null));
		contract.setFareType(fareTypeRepository.findById(contractDTOForm.getFareType()).orElse(null));
		contract.setDateReceived(contractDTOForm.getDateReceived());
		contract.setEffectiveDate(contractDTOForm.getEffectiveDate());
		contract.setDiscontinueDate(contractDTOForm.getDiscontinueDate());
		contract.setDateClarificationCleared(contractDTOForm.getDateClarificationCleared());
		contract.setNumberOfFareSheets(contractDTOForm.getNumberOfFareSheets());
		contract.setNumberOfFares(contractDTOForm.getNumberOfFares());
		contract.setRtgsActual(contractDTOForm.getRtgsActual());
		contract.setRtgsRecords(contractDTOForm.getRtgsRecords());
		contract.setNumberOfRules(contractDTOForm.getNumberOfRules());
		contract.setTotalRecords(contractDTOForm.getTotalRecords());
		contract.setQueuingStartDate(contractDTOForm.getQueuingStartDate());
		contract.setQueuingEndDate(contractDTOForm.getQueuingEndDate());

		return contract;
	}
}
