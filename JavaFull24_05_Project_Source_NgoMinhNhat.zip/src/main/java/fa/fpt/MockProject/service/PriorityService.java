package fa.fpt.MockProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fa.fpt.MockProject.entities.Priority;
import fa.fpt.MockProject.repository.PriorityRepository;

@Service
@Transactional
public class PriorityService {
	@Autowired
	private PriorityRepository priorityRepository;
	
	public List<Priority> findAll() {
		return priorityRepository.findAllByOrderByNameAsc();
	}
}
