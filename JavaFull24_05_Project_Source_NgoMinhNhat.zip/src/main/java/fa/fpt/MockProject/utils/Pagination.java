package fa.fpt.MockProject.utils;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Pagination {
    private int currentPage;
    private int previousPage;
    private int nextPage;
    private int totalPages;

    public Pagination(int currentPage, int previousPage, int nextPage, int totalPages) {
        this.currentPage = currentPage;
        this.previousPage = previousPage;
        this.nextPage = nextPage;
        this.totalPages = totalPages;
    }

    // Getters và Setters
    
    
    
    public static Pagination calculatePagination(int totalRecords, int currentPage, int recordsPerPage) {
        int totalPages = (int) Math.ceil((double) totalRecords / recordsPerPage);
        
        if (currentPage < 1) currentPage = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        int previousPage = (currentPage > 1) ? currentPage - 1 : 1;
        int nextPage = (currentPage < totalPages) ? currentPage + 1 : totalPages;

        System.out.println("Pagination details: currentPage=" + currentPage + ", totalPages=" + totalPages);

        return new Pagination(currentPage, previousPage, nextPage, totalPages);
    }

	@Override
	public String toString() {
		return "Pagination [currentPage=" + currentPage + ", previousPage=" + previousPage + ", nextPage=" + nextPage
				+ ", totalPages=" + totalPages + "]";
	}
}
