package fa.fpt.MockProject.utils;

public class Constant {
	public static final int SIZE_PAGE = 3;
	public static final String FILTER_ACTION = "filter";
}
