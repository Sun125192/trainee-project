package fa.fpt.MockProject.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ContractDTOList {

	private String contractNumber;

	private String airlineCode;

	private String market;

	private String region;

	private String fareType;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateReceived;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private LocalDate effectiveDate;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private LocalDate discontinueDate;

	private String priority;
	
	

	@Override
	public String toString() {
		return "ContractDTOList [contractNumber=" + contractNumber + ", airlineCode=" + airlineCode + ", market="
				+ market + ", region=" + region + ", fareType=" + fareType + ", dateReceived=" + dateReceived
				+ ", effectiveDate=" + effectiveDate + ", discontinueDate=" + discontinueDate + ", priority=" + priority
				+ "]";
	}



	/**
	 * @param contractNumber
	 * @param airlineCode
	 * @param market
	 * @param region
	 * @param fareType
	 * @param dateReceived
	 * @param effectiveDate
	 * @param discontinueDate
	 * @param priority
	 */
	public ContractDTOList(String contractNumber, String airlineCode, String market, String region, String fareType,
			LocalDate dateReceived, LocalDate effectiveDate, LocalDate discontinueDate, String priority) {
		super();
		this.contractNumber = contractNumber;
		this.airlineCode = airlineCode;
		this.market = market;
		this.region = region;
		this.fareType = fareType;
		this.dateReceived = dateReceived;
		this.effectiveDate = effectiveDate;
		this.discontinueDate = discontinueDate;
		this.priority = priority;
	}
	
	
}
