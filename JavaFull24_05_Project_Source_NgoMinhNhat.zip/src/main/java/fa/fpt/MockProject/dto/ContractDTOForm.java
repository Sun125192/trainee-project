package fa.fpt.MockProject.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ContractDTOForm {

    @NotBlank(message = "Contract Number must be entered.")
    @Size(max = 20)
    @Pattern(regexp = "^[A-Za-z0-9\\-]+$", message = "Contract Number must be in the format of alpha numeric.")
    private String contractNumber;

    @NotBlank(message = "Contract Name must be entered.")
    @Size(max = 100)
    private String contractName;

    private Long airlineCode;
    private Long countryCode;
    private String importantLevel;
    private Long priority;
    private String region;
    private String fareType;

    @NotNull(message = "Date Received must be entered.")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateReceived;

    @NotNull(message = "Effective Date must be entered.")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate effectiveDate;

    @NotNull(message = "Discontinue Date must be entered.")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate discontinueDate;

    @NotNull(message = "Date Clarification Cleared must be entered.")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateClarificationCleared;

    @NotNull(message = "Number of Fare Sheets must be entered.")
    @Min(value = 1, message = "Number of Fare Sheets must be a number and > 0.")
    @Max(value = 999, message = "")
    private Integer numberOfFareSheets;

    @NotNull(message = "Number of Fares must be entered.")
    @Min(value = 1, message = "Number of Fare must be a number and > 0.")
    @Max(value = 99999, message = "")
    private Integer numberOfFares;

    @NotNull(message = "Rtgs Actual must be entered.")
    @Min(value = 1, message = "Rtgs Actual must be a number and > 0.")
    @Max(value = 99999, message = "")
    private Integer rtgsActual;

    @NotNull(message = "Rtgs Records must be entered.")
    @Min(value = 1, message = "Rtgs Records must be a number and > 0.")
    @Max(value = 99999, message = "")
    private Integer rtgsRecords;

    @NotNull(message = "Number of Rules must be entered.")
    @Min(value = 1, message = "Number of Rules must be a number and > 0.")
    @Max(value = 999, message = "")
    private Integer numberOfRules;

    private Integer totalRecords;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate queuingStartDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate queuingEndDate = LocalDate.now();

	@Override
	public String toString() {
		return "ContractDTOForm [contractNumber=" + contractNumber + ", contractName=" + contractName + ", airlineCode="
				+ airlineCode + ", countryCode=" + countryCode + ", importantLevel=" + importantLevel + ", priority="
				+ priority + ", region=" + region + ", fareType=" + fareType + ", dateReceived=" + dateReceived
				+ ", effectiveDate=" + effectiveDate + ", discontinueDate=" + discontinueDate
				+ ", dateClarificationCleared=" + dateClarificationCleared + ", numberOfFareSheets="
				+ numberOfFareSheets + ", numberOfFares=" + numberOfFares + ", rtgsActual=" + rtgsActual
				+ ", rtgsRecords=" + rtgsRecords + ", numberOfRules=" + numberOfRules + ", totalRecords=" + totalRecords
				+ ", queuingStartDate=" + queuingStartDate + ", queuingEndDate=" + queuingEndDate + "]";
	}
    
    
}
