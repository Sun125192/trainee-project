package fa.fpt.MockProject.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FilterConTractDTO {
	private String market;
	private String airline;
	private String contractNumber = "NULL";
	private String fareType = "NULL";
	private String discontinueDate = "";
	private String effectiveDate = "";
	private String dateReceived = "";
}
